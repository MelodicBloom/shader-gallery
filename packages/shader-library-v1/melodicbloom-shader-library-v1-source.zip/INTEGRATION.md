# Repository integration note

## Verified repository state

The connected `MelodicBloom/shader-gallery` repository is currently a compact static WebGL/GitHub Pages project. Its recent history adds `abalone/index.html`, `abalone/shader.glsl`, and updates `docs/index.html`; the earlier scaffold contains `README.md`, `aurora/index.html`, `aurora/shader.glsl`, and `docs/index.html`. It does not currently contain the previously proposed npm/Vite source tree or `src/main.ts`.

## Overlay scope

This package introduces a parallel canonical library without deleting the existing static pages:

- `shaders/`: 15 WebGL2 shader folders with metadata and previews
- `src/core/ShaderPlayer.js`: shared runtime
- `tools/`: metadata validation, native shader compilation/rendering, preview generation, and docs build
- `schemas/`: metadata schema
- `manifest.json`: callable shader registry
- `.github/workflows/shader-ci.yml`: compile/render CI gate
- `netlify.toml`: static gallery build and publish configuration

## Deliberately excluded

- No patch was applied to `seed-loom`. The cited `src/main.ts` nullability failure belongs to that separate repository.
- Existing root shader pages were not overwritten. Migration can occur incrementally after the new library is reviewed.
