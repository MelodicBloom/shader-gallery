# MelodicBloom Shader Library v1

A compile-validated WebGL2 shader library containing 15 semantic shader families, deterministic previews, metadata-driven controls, and a framework-agnostic runtime.

## Included

- 15 repaired WebGL2 fragment shaders
- normalized `u_time`, `u_resolution`, and `u_mouse` uniforms
- `ShaderPlayer` with resize, pointer, uniform, replacement, capture, and deterministic-render APIs
- per-shader `meta.json`
- deterministic `preview.png`
- browser compile/render smoke tests
- static gallery page
- GitHub Actions and Netlify configuration

## Validate

```bash
npm test
```

The test builds a small native EGL/GLES3 validator, compiles and links every shader with SwiftShader or Mesa software rendering, renders a deterministic frame, and verifies visible pixel output.

## Generate previews

```bash
npm run generate:previews
```

## Core usage

```js
import { ShaderPlayer } from "./src/index.js";

const canvas = document.querySelector("canvas");
const player = new ShaderPlayer(
  canvas,
  "./shaders/aurora/abalone/shader.glsl",
  { autoStart: true }
);

await player.init();
player.setUniform("grain", 0.35);
player.setUniform("paletteShift", 0.45);
```

## Deterministic rendering

```js
player.setFixedTime(1.2345);
player.renderOnce({ time: 1.2345 });
const png = await player.captureFrame();
```

## Important repository finding

The live `MelodicBloom/shader-gallery` repository is currently a small static GitHub Pages project. It does not presently contain the previously proposed Vite/npm package architecture or a `src/main.ts`. The strict-null TypeScript failure mentioned in the supplied context belongs to `seed-loom`, not this repository.


## Apply to the existing GitHub repository

This archive is a root-level overlay for `MelodicBloom/shader-gallery`. Copy its contents into a feature branch, review the new `shaders/`, `src/`, `tools/`, `schemas/`, workflow, and deployment files, then run:

```bash
npm test
npm run generate:previews
npm run build:docs
```

The existing `aurora/`, `abalone/`, and `docs/` static pages can remain during migration. The new canonical shader assets live under `shaders/<category>/<slug>/`.
